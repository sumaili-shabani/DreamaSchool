<template>
    <div data-app>
        <!-- debit -->
        <div class="main-wrapper">
            <!-- header -->
            <NavMenu />
            <!-- Fin header -->

            <!-- slideBar -->
            <NavigationLayout :linkAdmin="linkAdmin" />
            <!-- fin slider -->

            <!-- router here -->

            <div class="page-wrapper pagehead">
                <div class="content">
                    <transition name="fade" mode="out-in">
                        <router-view></router-view>
                    </transition>
                </div>
            </div>
            <!-- router here -->
        </div>
        <!-- fin -->
    </div>
</template>
<script>
import NavMenu from "../Application/Layout/NavMenu.vue";
import NavigationLayout from "../Application/Layout/navigationLayout.vue";

export default {
    components: {
        NavMenu,
        NavigationLayout,
    },
    data() {
        return {
            linkAdmin: [],
        };
    },
    methods: {
        testLink() {
            if (this.userData.id_role == 1) {
                this.linkAdmin = {
                    linkAdmin: {
                        links: [
                            // {
                            //     icon: "dashboard",
                            //     text: "Tableau de bord",
                            //     href: "/admin/dashboard",
                            // },

                            // {
                            //     icon: "event",
                            //     text: "Calendrier",
                            //     href: "/admin/page_event",
                            // },
                        ],

                        listGroup: [
                            {
                                text: "Reception",
                                icon: "room_preferences",
                                items: [
                                    {
                                        icon: "person",
                                        text: "Elève",
                                        href: "/admin/eleve",
                                    },
                                    {
                                        icon: "data_table",
                                        text: "Inscription",
                                        href: "/admin/inscription",
                                    },
                                    {
                                        icon: "credit_card_gear",
                                        text: "Présences",
                                        href: "/admin/presence",
                                    },
                                    {
                                        icon: "transfer1",
                                        text: "Clauture d'Effectif",
                                        href: "/admin/clauture_effectif",
                                    },
                                ],
                            },

                            {
                                text: "Ventes & Stock",
                                icon: "room_preferences",
                                items: [
                                    {
                                        icon: "room_preferences",
                                        text: "Ventes",
                                        href: "/admin/VenteEnteteVente",
                                    },
                                    {
                                        icon: "room_preferences",
                                        text: "Approvisionnements",
                                        href: "/admin/VenteEnteteEntree",
                                    },
                                    {
                                        icon: "room_preferences",
                                        text: "Etat de Besoin",
                                        href: "/admin/VenteEnteteCommande",
                                    },
                                    {
                                        icon: "room_preferences",
                                        text: "Produits",
                                        href: "/admin/Produits",
                                    },
                                    {
                                        icon: "room_preferences",
                                        text: "Fournisseurs",
                                        href: "/admin/Fournisseur",
                                    },
                                    {
                                        icon: "room_preferences",
                                        text: "Rapports",
                                        href: "/admin/RapportsJour_Vente",
                                    },

                                ],
                            },

                            {
                                text: "Finances",
                                icon: "wallet1",
                                items: [
                                    {
                                        icon: "payments",
                                        text: "Paiement",
                                        href: "/admin/finances_paiement",
                                    },
                                    {
                                        icon: "payments",
                                        text: "Recettes",
                                        href: "/admin/recette",
                                    },
                                    {
                                        icon: "payments",
                                        text: "Depenses",
                                        href: "/admin/depenseAll",
                                    },
                                    // {
                                    //     icon: "payments",
                                    //     text: "Etat de Besoin",
                                    //     href: "/admin/EnteteEtatBesoin",
                                    // },
                                    // {
                                    //     icon: "payments",
                                    //     text: "Bon d'Engagement",
                                    //     href: "/admin/EnteteBonEngagement",
                                    // },
                                    {
                                        icon: "payments",
                                        text: "Cloture de la Caisse",
                                        href: "/admin/Cloture_Caisse",
                                    },
                                    { 
                                        icon: "payments",
                                        text: "Comptabilité(Opé.)",
                                        href: "/admin/EnteteOperationComptable",
                                    },
                                    { 
                                        icon: "payments",
                                        text: "Cloture de la Comptabilité",
                                        href: "/admin/ClotureComptabilite",
                                    },
                                    {
                                        icon: "payments",
                                        text: "Rapport Comptabilité",
                                        href: "/admin/RapportsComptabilite"                                    
                                    },
                                    {
                                        icon: "payments",
                                        text: "Rapport Recettes/Depenses",
                                        href: "/admin/RapportsJour_Caisse"
                                    },
                                    {
                                        icon: "payments",
                                        text: "Les Services",
                                        href: "/admin/Services"
                                    },
                                ],
                            },

                            {
                                text: "Statistiques",
                                icon: "area_chart",
                                items: [
                                    {
                                        icon: "insert_chart",
                                        text: "Elèves",
                                        href: "/admin/StatistqueEleve",
                                    },
                                    {
                                        icon: "insert_chart",
                                        text: "Finances",
                                        href: "/admin/StatistiqueFinance",
                                    },
                                    {
                                        icon: "insert_chart",
                                        text: "Utilisateurs",
                                        href: "/admin/statistique_user",
                                    },
                                ],
                            },
                            {
                                text: "Rapports",
                                icon: "time",
                                items: [
                                    // {
                                    //     icon: "person",
                                    //     text: "Rap sur Eleve",
                                    //     href: "/admin/rapport_inscription",
                                    // },
                                    {
                                        icon: "data_table",
                                        text: "Rap sur Inscription",
                                        href: "/admin/rapport_inscription",
                                    },
                                    // {
                                    //     icon: "credit_card_gear",
                                    //     text: "Rap sur Présences",
                                    //     href: "/admin/rapport_presence",
                                    // },
                                    {
                                        icon: "credit_card",
                                        text: "Rap sur Paiement",
                                        href: "/admin/rapport_paiement",
                                    },
                                    // {
                                    //     icon: "event",
                                    //     text: "Feuille Echeancier ",
                                    //     href: "/admin/rapport_echeance",
                                    // },

                                ],
                            },
                        ],
                        listGroupMenu: [
                            {
                                text: "Configurations",
                                icon: "credit_card_gear",
                                submenu: [
                                    {
                                        text: "Scolarité",
                                        icon: "box",
                                        items: [
                                            {
                                                icon: "api",
                                                text: "Année scolaire",
                                                href: "/admin/annee_scolaire",
                                            },

                                            {
                                                icon: "api",
                                                text: "Classes",
                                                href: "/admin/classes",
                                            },
                                            {
                                                icon: "api",
                                                text: "Options",
                                                href: "/admin/options",
                                            },
                                            {
                                                icon: "api",
                                                text: "Sections",
                                                href: "/admin/sections",
                                            },
                                            {
                                                icon: "api",
                                                text: "Divisions",
                                                href: "/admin/divisions",
                                            },
                                            {
                                                icon: "event",
                                                text: "Mois scolaires",
                                                href: "/admin/mois_scolaire",
                                            },
                                        ],
                                    },
                                    {
                                        text: "Localisation",
                                        icon: "expense1",

                                        items: [
                                            {
                                                icon: "api",
                                                text: "Pays",
                                                href: "/admin/pays",
                                            },
                                            {
                                                icon: "api",
                                                text: "Provinces",
                                                href: "/admin/provinces",
                                            },

                                            {
                                                icon: "api",
                                                text: "Chef lieu",
                                                href: "/admin/ville",
                                            },
                                            {
                                                icon: "api",
                                                text: "Commune",
                                                href: "/admin/commune",
                                            },

                                            {
                                                icon: "api",
                                                text: "Quartier",
                                                href: "/admin/quartier",
                                            },

                                            {
                                                icon: "api",
                                                text: "Avenue",
                                                href: "/admin/avenue",
                                            },
                                        ],
                                    },
                                    {
                                        text: "Paiement frais",
                                        icon: "cases",
                                        items: [
                                            {
                                                icon: "bid_landscape",
                                                text: "Tranche",
                                                href: "/admin/paiement_tranche",
                                            },
                                            {
                                                icon: "card_membership",
                                                text: "Frais",
                                                href: "/admin/paiement_frais",
                                            },
                                            {
                                                icon: "corporate_fare",
                                                text: "Prevision",
                                                href: "/admin/paiement_prevision",
                                            },
                                        ],
                                    },

                                    {
                                        text: "Finance(Comptabilité)",
                                        icon: "box",
                                        items: [
                                        {
                                            icon: "groups",
                                            text: "Classes",
                                            href: "/admin/ClassesFin",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Comptes",
                                            href: "/admin/CompteFin",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Sous Comptes",
                                            href: "/admin/SousCompte",
                                        },
                                        {
                                            icon: "groups",
                                            text: "SSous Comptes",
                                            href: "/admin/SSousCompte",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Type Compte",
                                            href: "/admin/TypeCompte",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Config. Taux",
                                            href: "/admin/TTaux",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Type Position",
                                            href: "/admin/TypePosition",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Type Opération",
                                            href: "/admin/TypeOperation",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Rubriques",
                                            href: "/admin/Comptes",
                                        },
                                        {
                                            icon: "groups",
                                            text: "Caisse&Banque",
                                            href: "/admin/Banque",
                                        },
                                        {
                                            icon: "groups",
                                            text: "ModePaie",
                                            href: "/admin/modepaie",
                                        }
                                        // {
                                        //   icon: "groups",
                                        //   text: "Services Treseorerie",
                                        //   href: "/admin/Provenance",
                                        // },
                                        // {
                                        //   icon: "groups",
                                        //   text: "Cat. Rubriques",
                                        //   href: "/admin/CategorieRubrique",
                                        // },
                                        // {
                                        //   icon: "groups",
                                        //   text: "Rubriques Depenses",
                                        //   href: "/admin/Rubriques",
                                        // },
                                        // {
                                        //   icon: "groups",
                                        //   text: "Blocs",
                                        //   href: "/admin/Blocs",
                                        // }

                                        ],
                                    },

                                    {
                                        text: "Trésorerie",
                                        icon: "box",
                                        items: [
                                            {
                                                icon: "api",
                                                text: "Rubriques Depenses",
                                                href: "/admin/Comptes",
                                            },
                                            {
                                                icon: "api",
                                                text: "Cat.Rubriques EB",
                                                href: "/admin/CategorieRubrique",
                                            },
                                            {
                                                icon: "api",
                                                text: "Rubriques EB",
                                                href: "/admin/Rubriques",
                                            },
                                            {
                                                icon: "api",
                                                text: "Blocs(Finances)",
                                                href: "/admin/Blocs",
                                            },
                                            {
                                                icon: "api",
                                                text: "Les Services(Finances)",
                                                href: "/admin/Provenance",
                                            }
                                        ],
                                    },

                                    {
                                        text: "Ventes & Stock",
                                        icon: "conveyor_belt",
                                        items: [                                        
                                            {
                                                icon: "groups",
                                                text: "CatégorieProduit",
                                                href: "/admin/CategorieProduit",
                                            }
                                        ],
                                    },
                                ],
                            },

                            {
                                text: "Paramètrage",
                                icon: "settings",
                                submenu: [
                                    {
                                        text: "Systèmes",
                                        icon: "settings_applications",
                                        items: [
                                            {
                                                icon: "domain",
                                                text: "Application",
                                                href: "/admin/configure_site",
                                            },
                                        ],
                                    },

                                    {
                                        text: "Comptes",
                                        icon: "credit_card_gear",
                                        items: [
                                            {
                                                icon: "group",
                                                text: "utilisateur",
                                                href: "/admin/compte",
                                            },
                                            {
                                                icon: "settings",
                                                text: "Privilège",
                                                href: "/admin/role",
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                };
            } else if (this.userData.id_role == 2) {
                this.linkAdmin = {
                    linkAdmin: {
                        links: [
                            {
                                icon: "dashboard",
                                text: "Tableau de bord",
                                href: "/user/dashboard",
                            },
                            {
                                icon: "time",
                                text: "Rapport",
                                href: "/user/page_rapport",
                            },
                            {
                                icon: "event",
                                text: "Calendrier",
                                href: "/user/page_event",
                            },
                        ],

                        listGroup: [
                            {
                                text: "Statistiques",
                                icon: "area_chart",
                                items: [
                                    {
                                        icon: "insert_chart",
                                        text: "Statistique sur Les utilisateur",
                                        href: "/user/statistique_user",
                                    },
                                ],
                            },
                        ],
                        listGroupMenu: [
                            {
                                text: "Configurations",
                                icon: "credit_card_gear",
                                submenu: [
                                    {
                                        text: "Configurations",
                                        icon: "box",
                                        items: [
                                            {
                                                icon: "data_table",
                                                text: "Configurations 1",
                                                href: "/user/operation_configuration_1",
                                            },

                                            {
                                                icon: "api",
                                                text: "Configurations 2",
                                                href: "/user/operation_configuration_2",
                                            },
                                        ],
                                    },
                                    {
                                        text: "Autorisation",
                                        icon: "conveyor_belt",
                                        items: [
                                            {
                                                icon: "api",
                                                text: "Autorisation 1",
                                                href: "/user/operation_aut_1",
                                            },

                                            {
                                                icon: "api",
                                                text: "Autorisation 2",
                                                href: "/user/operation_aut_2",
                                            },
                                        ],
                                    },
                                ],
                            },

                            {
                                text: "Paramètrage",
                                icon: "settings",
                                submenu: [
                                    {
                                        text: "Comptes",
                                        icon: "credit_card_gear",
                                        items: [
                                            {
                                                icon: "person",
                                                text: "Mon profil",
                                                href: "/user/profil",
                                            },
                                            {
                                                icon: "lock",
                                                text: "Sécurité",
                                                href: "/user/security",
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                };
            } else if (this.userData.id_role == 3) {
                this.linkAdmin = {
                    linkAdmin: {
                        links: [
                            {
                                icon: "dashboard",
                                text: "Tableau de bord",
                                href: "/entreprise/dashboard",
                            },
                            {
                                icon: "time",
                                text: "Rapport",
                                href: "/entreprise/page_rapport",
                            },
                            {
                                icon: "event",
                                text: "Calendrier",
                                href: "/entreprise/page_event",
                            },
                        ],

                        listGroup: [
                            {
                                text: "Statistiques",
                                icon: "area_chart",
                                items: [
                                    {
                                        icon: "insert_chart",
                                        text: "Statistique sur Les utilisateur",
                                        href: "/entreprise/statistique_entreprise",
                                    },
                                ],
                            },
                        ],
                        listGroupMenu: [
                            {
                                text: "Configurations",
                                icon: "credit_card_gear",
                                submenu: [
                                    {
                                        text: "Configurations",
                                        icon: "box",
                                        items: [
                                            {
                                                icon: "data_table",
                                                text: "Configurations 1",
                                                href: "/entreprise/operation_configuration_1",
                                            },

                                            {
                                                icon: "api",
                                                text: "Configurations 2",
                                                href: "/entreprise/operation_configuration_2",
                                            },
                                        ],
                                    },
                                    {
                                        text: "Autorisation",
                                        icon: "conveyor_belt",
                                        items: [
                                            {
                                                icon: "api",
                                                text: "Autorisation 1",
                                                href: "/entreprise/operation_aut_1",
                                            },

                                            {
                                                icon: "api",
                                                text: "Autorisation 2",
                                                href: "/entreprise/operation_aut_2",
                                            },
                                        ],
                                    },
                                ],
                            },

                            {
                                text: "Paramètrage",
                                icon: "settings",
                                submenu: [
                                    {
                                        text: "Comptes",
                                        icon: "credit_card_gear",
                                        items: [
                                            {
                                                icon: "person",
                                                text: "Mon profil",
                                                href: "/entreprise/profil",
                                            },
                                            {
                                                icon: "lock",
                                                text: "Sécurité",
                                                href: "/entreprise/security",
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                };
            } else {
            }
        },
    },
    computed: {},
    created() {
        this.$vuetify.theme.dark = false;
        this.testLink();
    },
};
</script>

<style scoped>
.sidebar-menu>ul>li a {
    text-decoration: none;
}
</style>
